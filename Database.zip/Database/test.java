// This File is specifically for testing the database functions and not part of main project.

public class test
{
    public test()
    {
       
    }

    public static void main(String[] args)
    {
        Database data = new Database();
        String code = null;
        //data.UpdateData(1,"Big_Man");
        //data.ShowAll();
        //data.InsertData(3, "Fuzzy");
        //code = data.ReturnCodeName(4);
        //System.out.println("Code Name: " + code);

        data.CloseConnection();
    }
}